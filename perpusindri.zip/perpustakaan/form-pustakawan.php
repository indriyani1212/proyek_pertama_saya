<?php
    include "cek_sesi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="form.css">
</head>
<body>
     <header><p> APLIKASI PERPUSTAKAAN</p></header> 
     <p> 
       <strong>HALO, <?php echo $_SESSION['pengguna'];?></strong>
       <a href="logout,php">logout</a>
    </p>
     <section>
             <article>
    <form method="post" action="simpanb.php">
             <table class="tbb">
                <tr>
                    <td></td>
                    <td>:</td>
                    <td>
                        <input type="date" name="beli_tgl" required>
                    </td>
                    </tr>
                        <td>Barang</td>
                        <td>:</td>
                        <td>
                        <select name="barang_id" required>
                            <?php
                            include "koneksi.php";
                            $sqlbarang=mysqli_query($koneksi,"CALL tampil_pembelian()");
                            while($row=mysqli_fetch_array($sqlbarang)){
                                echo "<option>$row[id_barang]-$row[barang_nama]</option>";
                            }
                            ?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Harga Satuan Pembelian</td>
                        <td>:</td>
                        <td>
                          <input type="number" name="beli_harga_satuan" required>
                      </td>
                    </tr>
                    <tr>
                        <td>Jumlah Pembelian</td>
                        <td>:</td>
                        <td>
                          <input type="number" name="beli_jumlah" required>
                      </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td><button type="sumbit">Simpan</button></td>
                    </tr>
                 </table>
           </form>
                <table border="1" cellpadding="5"> >
                    <tr>
                    <td>NO</td>
                    <td>Tanggal Pembelian</td>
                    <td>Barang</td>
                    <td>Harga Satuan</td>
                    <td>Jumlah pembelian</td>
                    <td>TINDAKAN</td>
        </tr>
        <?php
            include "koneksi.php";
            $no=0;
            $panggilsql=mysqli_query($koneksi, "CALL tampil_pembelian()");
            while($data=mysqli_fetch_array($panggilsql)) {
                 $no++;
                 echo "
                 <tr>
                  <td>$no</td>
                  <td>$data[beli_tgl]</td>
                  <td>$data[barang_id]</td>
                  <td>$data[beli_harga_satuan]</td>
                  <td>$data[beli_jumlah]</td>
                  <td>
                        <form method='post' action='editb.php'>
                        <input type='hidden' name='beli_id' value='$data[beli_id]'>
                        <button type='submit'>edit</button>
                        </form>
                        <form method='post' action='hapusb.php'>
                        <input type='hidden' name='beli_id' value='$data[beli_id]'>
                        <button type='submit'>hapus</button>
                </form>
                </td>
                </tr>";
            }
        ?>
        </table>
        </article>
        </body>
</html>
         